
# Python Products

A Python/Flask dashboard sample for use with GitHub Codespaces.

## Run the application

1. Open this repository in a codespace.
2. Install your requirements by running `pip install -r requirements.txt`
3. Hit `F5` to start debugging.
4. Follow the toast to "Open forwarded port" and see your application.
